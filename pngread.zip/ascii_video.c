#include <stdio.h>
#include "ascii_video.h"

#define BUFFER_SIZE 64

void read_png(char * path) {
	unsigned char buffer[BUFFER_SIZE];
	unsigned char magic_number[8];
	unsigned char header[25];
	
	
	FILE * ptr = fopen(path, "rb");
	
	// Ler o Número mágico.
	fread(magic_number, 8, 1, ptr);
	printf("Número Mágico: ");
	for(int i=0;i<8;i++)
		printf("%02X ",magic_number[i]);
	printf("\n");
	
	// Lê o Image Header
	fread(header, 25, 1, ptr);
	printf("%c%c%c%c -----------------\n",header[4], header[5], header[6], header[7]);
	printf("Tamanho do Chunk: %d\n", (int)header[3]);	
	
	int width  = (header[11] << 24) | (header [10] << 8) | (header[9] >> 8) | (header[8] >> 24);
	int height = (header[15] << 24) | (header [14] << 8) | (header[13] >> 8) | (header[12] >> 24);
	printf("Largura: %d\n", width);
	printf("Altura: %d\n", height);
	printf("Bits/pixel: %d\n", (int)header[16]);
	printf("Color Type(RGB/Truecolor): %d\n", (int)header[17]);
	printf("Tipo de Compressão: %d\n", (int)header[18]);
	printf("Metodo de filtragem: %d\n", (int)header[19]);
	printf("Interlaced: %d\n", (int)header[20]);
	printf("0x%02X%02X%02X%02X\n", header[21], header[22], header[23], header[24]);
}

